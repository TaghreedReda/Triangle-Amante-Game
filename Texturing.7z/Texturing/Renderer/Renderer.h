#ifndef Renderer_h__
#define Renderer_h__

#include <gl/glew.h>
#include <gl/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <memory>


#include "Shaders/shader.hpp"
#include "Texture/texture.h"
#include "Model/Model.h"
#include "FPCamera/FPCamera.h"
#include "EulerCamera/EulerCamera.h"
//#include "Application Manager/ApplicationManager.h"
class Renderer
{
	enum RenderingMode
	{
		NO_TEXTURE,
		TEXTURE_ONLY,
		BLEND
	};

    GLuint programID;
    
	// Transformation
	GLuint MatrixID;
	
	std::unique_ptr<Model> myTriangle;



	//std::unique_ptr<FPCamera> myCamera;
	std::unique_ptr<EulerCamera> myCamera;
	

	//collectables
	std::unique_ptr<Model> collectables;
	std::unique_ptr<Texture> collectablesTexture;
	glm::mat4 collectablesFM;
	glm::mat4 collectablesBM;
	glm::mat4 collectablesRM;
	glm::mat4 collectablesLM;
	glm::mat4 collectablesTM;



	//hero object
	std::unique_ptr<Model> hero;
	//hero texture for each face
	std::unique_ptr<Texture> heroFrontTexture;
	std::unique_ptr<Texture> heroBackTexture;
	std::unique_ptr<Texture> heroTopTexture;
	std::unique_ptr<Texture> heroLeftTexture;
	std::unique_ptr<Texture> heroRightTexture;
	std::unique_ptr<Texture> heroBottomTexture;
	//hero modle for each face
	glm::mat4 heroFM;
	glm::mat4 heroBM;
	glm::mat4 heroRM;
	glm::mat4 heroLM;
	glm::mat4 heroTM;
	glm::mat4 heroBtM;


	//maze
	std::unique_ptr<Model> maze;
	glm::mat4 mazeM;



	GLuint mRenderingModeID;
	RenderingMode mRenderingMode;

	glm::mat4 triangle1M;
	glm::mat4 triangle2M;
	glm::mat4 triangle3M;
	glm::mat4 triangle4M;

	std::unique_ptr<Texture> mTexture1;
	std::unique_ptr<Texture> mTexture2;

	glm::mat4 skybox;


public:
    Renderer();
    ~Renderer();
	bool done;
    
	void Initialize();
    void Draw();
	void HandleKeyboardInput(int key);
	void HandleMouse(double deltaX,double deltaY);
	void Update(double deltaTime);
    void Cleanup();
};

#endif // Renderer_h__